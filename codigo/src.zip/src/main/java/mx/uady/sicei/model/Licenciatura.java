package mx.uady.sicei.model;

public enum Licenciatura {
    LCC,
    LIC,
    LIS,
    LA,
    LM
}
